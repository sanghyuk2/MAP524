package com.example.midterm2_skeletonproject;

import android.graphics.Bitmap;

public class Car {

    String OwnerName;
    Bitmap imageData;
    int year;
    String model;
}
