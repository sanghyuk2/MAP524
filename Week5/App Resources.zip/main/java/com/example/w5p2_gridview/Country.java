package com.example.w5p2_gridview;

public class Country {


        int image;
        int name;

        public Country(int image, int name) {
            this.image = image;
            this.name = name;
        }

    public int getImage() {
        return image;
    }

    public int getName() {
        return name;
    }
}

