package com.example.assignment2_skeletonproject;

public class NetworkingManager {

    //url = "https://raw.githubusercontent.com/RaniaArbash/Assignment2_SkeletonProject/master/cars.json"
}
