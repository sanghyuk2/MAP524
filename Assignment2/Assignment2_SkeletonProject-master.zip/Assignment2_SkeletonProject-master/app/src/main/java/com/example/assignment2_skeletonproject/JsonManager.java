package com.example.assignment2_skeletonproject;

public class JsonManager {
}
