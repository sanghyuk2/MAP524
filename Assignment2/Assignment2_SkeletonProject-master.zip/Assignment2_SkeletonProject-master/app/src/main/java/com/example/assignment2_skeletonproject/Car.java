package com.example.assignment2_skeletonproject;

public class Car {

    int id;
    String carModel1;
    String carModel2;
    Double year;
}
