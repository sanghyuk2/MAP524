package com.example.assignment2_danielPark;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements NetworkingManager.APIJSONListener, CarAdapter.AlertDialogListener {
    NetworkingManager networkingManager;
    JsonManager jsonManager;
    ArrayList<Car> carArrayList = new ArrayList<>();
    RecyclerView recyclerView;
    CarAdapter adapter;
    DatabaseClient dbClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        jsonManager = new JsonManager();
        // Get Car JSON Data from API (Github url)
        networkingManager = new NetworkingManager(this, getApplicationContext());
        networkingManager.getCarAPIData();
        recyclerView = findViewById(R.id.favoriteCarList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        dbClient = DatabaseClient.getInstance(this);
        Log.d("check","addedt o Room DB");
    }


    // Callback interface from NetworkingManager
    @Override
    public void returnAPIJSONData(String data) {
        Log.d("jsontest", data);
        ArrayList<Car> result = jsonManager.parseCarData(data);
        // Update recycler view with ArrayList
        carArrayList = new ArrayList<Car>();
        carArrayList.addAll(result);
        recyclerView.setAdapter(new CarAdapter(this, carArrayList));
    }

    // Callback listener called when favourite car added to Room DB. Updates view and fav icon
    @Override
    public void alertDialogAfterSavingCity() {
        recyclerView.setAdapter(new CarAdapter(this,carArrayList));
        recyclerView.invalidate(); // Refresh our RecyclerView with new data

    }
}
