package com.example.assignment2_danielPark;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

//url = "https://raw.githubusercontent.com/RaniaArbash/Assignment2_SkeletonProject/master/cars.json"


// API that returns JSON data retrieved from URL, to Activity using callback interface
// Uses background Thread+Handler+Looper to asynchronously retrieve data via HttpURLConnection
public class NetworkingManager {

    // Reference to Activity that implements interface
    // Enables NetworkingManager to return API data to that Activity
    APIJSONListener activity;
    Context mainActivityContext;

    // Provided github link for Cars JSON data
    final String carsURL = "https://raw.githubusercontent.com/RaniaArbash/Assignment2_SkeletonProject/master/cars.json";

    // Callback interface implemented by Activity that wants to receive API data
    public interface APIJSONListener {
        // NetworkingManager calls and passes retrieved JSON String data -
        public void returnAPIJSONData(String data);
    }

    // Constructor called in Activity. Activity passes reference to itself.
    NetworkingManager(APIJSONListener listener, Context context) {
        this.activity = listener;
        this.mainActivityContext = context;
    }

    // API method called to retrieve cars JSON from provided github link
    void getCarAPIData() {
        // JSON retrieved by http, is then sent via the callback interface to Activity
        connectToAPI(carsURL);
    }

    void connectToAPI(final String url) {
        try {

            // New Thread that will run in background
            Thread thread = new Thread() {

                public void run() {
                    // Looper class runs a message loop (MessageQueue) for a thread, keeps thread alive,
                    Looper.prepare(); // gives thread a Looper and MessageQueue

                    // Handler executes tasks when they come out of MessageQueue
                    final Handler handler = new Handler();

                    handler.postDelayed(new Runnable() { // .post queues a Runnable in MessageQueue
                        @Override
                        public void run() { // Call this thread in run function
                            String data = "";
                            HttpURLConnection httpURLConnection = null;
                            try {

                                httpURLConnection = (HttpURLConnection) new URL(url).openConnection();
                                httpURLConnection.setRequestMethod("GET");
                                httpURLConnection.setRequestProperty("Content-Type", "application/json");

                                int status = httpURLConnection.getResponseCode();
                                Log.d("GET RX", " status=> " + status);

                                try {
                                    InputStream in = httpURLConnection.getInputStream();
                                    InputStreamReader inputStreamReader = new InputStreamReader(in);
                                    int inputStreamData = inputStreamReader.read();
                                    while (inputStreamData != -1) {
                                        char current = (char) inputStreamData;
                                        inputStreamData = inputStreamReader.read();
                                        data += current;
                                    }
                                    final String finalData = data;
                                    Log.d("jsonText",finalData);
                                    // Return data from this BG thread to Main UI thread
                                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                                        @Override
                                        public void run() {
                                            //Callback listener implemented in Activity
                                            // returns JSON data to Activity
                                            activity.returnAPIJSONData(finalData);
                                        }
                                    });


                                }

                                catch (Exception exx) {
                                    Log.d("error", exx.toString());
                                }
                            }
                            catch (Exception e) {
                                Log.e("TX", " error => " + e.getMessage());
                                e.printStackTrace();
                            } finally {
                                if (httpURLConnection != null) {
                                    httpURLConnection.disconnect();
                                }
                            }

                            handler.removeCallbacks(this); // Remove pending posts/runnables in MessageQueue
                            Looper.myLooper().quit(); // Returns Looper object associated with current thread and closes it
                        }
                    }, 1000);

                    Looper.loop(); // have thread process messages until loop is stopped
                }
            };
            thread.start(); // Start thread after thread is prepared

        } catch (Exception ex) {
            Log.e("ERROR =>", "" + ex.getMessage());
            ex.printStackTrace();
        }
    }




}
