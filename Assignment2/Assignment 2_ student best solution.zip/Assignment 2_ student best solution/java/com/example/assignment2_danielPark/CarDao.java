package com.example.assignment2_danielPark;


import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface CarDao {

    @Query("SELECT * FROM Car")
    public List<Car> getAllCars();

    @Query("SELECT * FROM Car WHERE carID == :ID")
    public Car checkFavouriteCar(int ID);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public void insertCar(Car car);


}
