package com.example.assignment2_danielPark;

import android.content.Context;

import androidx.room.Room;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DatabaseClient {

    private static CarDatabase donationsDatabase;
    public static DatabaseClient dbInstance;
    private Context mcontext;

    public static final ExecutorService databaseWriteExecutor = Executors.newFixedThreadPool(4);

    private DatabaseClient(Context context) {
        this.mcontext = context;
        // Build Room database containing persisted Donations object
        donationsDatabase = Room.databaseBuilder(context, CarDatabase.class, "AllDonations").build();
    }

    public static synchronized DatabaseClient getInstance(Context context) {
        if (dbInstance == null) {
            dbInstance = new DatabaseClient(context);
        }
        return dbInstance;
    }

    public static CarDatabase getAppDatabase() {
        return donationsDatabase;
    }

    public static void insertFavouriteCar(Context context, Car car){
        DatabaseClient.databaseWriteExecutor.execute(()->{
            DatabaseClient.getInstance(context).getAppDatabase()
                    .carDao()
                    .insertCar(car);
        });
    }

}
