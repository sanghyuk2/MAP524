package com.example.assignment2_danielPark;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static android.text.TextUtils.indexOf;
import static android.text.TextUtils.substring;

public class JsonManager {

    public ArrayList<Car> parseCarData(String json) {
        ArrayList<Car> carsFromAPI = new ArrayList<>();
        JSONObject jsonObject = null;

        try {
            JSONArray array =  new JSONArray(json);
            for (int i = 0 ; i< array.length(); i++){
                jsonObject = array.getJSONObject(i);
                int id = jsonObject.getInt("id");
                String carModel1 = jsonObject.getString("CarModel1");
                String carModel2 = jsonObject.getString("CarModel2");
                double year = jsonObject.getDouble("Year");
                Car car = new Car(id,carModel1,carModel2,year, false);
                carsFromAPI.add(car);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return carsFromAPI;
    }

}
