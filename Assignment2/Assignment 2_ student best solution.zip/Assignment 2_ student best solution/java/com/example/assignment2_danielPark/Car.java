package com.example.assignment2_danielPark;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity
public class Car {
    //    @PrimaryKey(autoGenerate = true)
//    @ColumnInfo(name = "_id")
//    private int id;
    @PrimaryKey
    int carID;
    String carModel1;
    String carModel2;
    Double year;
    Boolean isFavorite = false;

    Car(){}

    public Car(int carID, String carModel1, String carModel2, double year, Boolean isFavorite){
        this.carID = carID;
        this.carModel1 = carModel1;
        this.carModel2 = carModel2;
        this.year = year;
        this.isFavorite = isFavorite;
    }

    public void setCarModel1(String carModel1) {
        this.carModel1 = carModel1;
    }
    public String getCarModel1() {
        return carModel1;
    }

    public void setCarModel2(String carModel2) {
        this.carModel2 = carModel2;
    }
    public String getCarModel2() {
        return carModel2;
    }

    public int getId() {
        return carID;
    }
    public void setId(int id) {
        this.carID = id;
    }

    public void setCarYear(double year) {
        this.year = year;
    }
    public double getCarYear() {
        return year;
    }

    public Boolean getIsFavorite() {
        return isFavorite;
    }
    public void setIsFavorite(Boolean isFavorite) {
        this.isFavorite = isFavorite;
    }





}
