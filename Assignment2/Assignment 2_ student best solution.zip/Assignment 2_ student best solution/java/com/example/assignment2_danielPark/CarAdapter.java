package com.example.assignment2_danielPark;


import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class CarAdapter extends RecyclerView.Adapter<CarAdapter.CarViewHolder>{

    // Called in Adapter when favorite saved to Room DB
    // Implemented by Activity to reset RecyclerView Adapterview to change new icon to favourite
    interface AlertDialogListener {
        public void alertDialogAfterSavingCity();
    }

    private Context mContext;
    private ArrayList<Car> carArrayList;
    AlertDialogListener listener;



    public CarAdapter(Context context, ArrayList<Car> carArrayList) {
        this.mContext = context;
        this.carArrayList = carArrayList;
        this.listener = (AlertDialogListener) context;
//        // test Database
//        DatabaseClient.databaseWriteExecutor.execute(()-> {
//            List<Car> tempCarList = DatabaseClient.getAppDatabase().carDao().getAllCars();
//            Log.d("BLABLA", String.valueOf(tempCarList.size()));
//        });
    }


    //
    @Override
    public CarViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.recyclerview_cars, parent, false);
        // ViewHolder constructed with view for single RecyclerView list item
        return new CarViewHolder(view);
    }

    @Override
    public void onBindViewHolder(CarViewHolder holder, int position) {
        Car c = carArrayList.get(position);
        holder.carModel1TextView.setText(c.getCarModel1());
        holder.carModel2TextView.setText(c.getCarModel2());

        // Query Room DB if current Car has been saved
        // If it is favourite change Icon to liked
        DatabaseClient.databaseWriteExecutor.execute(()-> {
            Car result = DatabaseClient.getAppDatabase().carDao().checkFavouriteCar(c.getId());
            if (result == null) {
                Log.d("CAR RESULT", c.getCarModel1() + " is not in");
            } else {
                if(result.isFavorite == true) { // If car is favourite then icon can be changed
                    holder.likeDislikeImageView.setImageResource(R.drawable.like);
                }

            }
        });
    }

    @Override
    public int getItemCount() {
        return carArrayList.size();
    }


    // Displays car in CardView widget
    class CarViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView carModel1TextView, carModel2TextView;
        ImageView likeDislikeImageView;

        public CarViewHolder(View itemView) {
            super(itemView);
            carModel1TextView = itemView.findViewById(R.id.carModel1);
            carModel2TextView = itemView.findViewById(R.id.carModel2);
            likeDislikeImageView = itemView.findViewById(R.id.likeDislike);
            itemView.setOnClickListener(this);
        }


        // When Car clicked, launch AlertDialog to save as a favorite to Room DB
        @Override
        public void onClick(View view) {
            Car car = carArrayList.get(getAdapterPosition());
            new AlertDialog.Builder(mContext)
                    .setTitle("Favorite Car?")
                    .setMessage("Are you sure you want to insert "+ car.getCarModel1()+" to Database?")
                    .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            car.setIsFavorite(true); // Sets favorite status to True
                            DatabaseClient.insertFavouriteCar(mContext, car);
                            // Callback interface to UI in MainActivity to change icon to liked
                            listener.alertDialogAfterSavingCity();
                        }
                    })
                    .setNegativeButton(android.R.string.no, null)
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .show();

        }
    }
}
