package com.example.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SwitchCompat;

import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;
import android.content.DialogInterface;

public class MainActivity extends AppCompatActivity {

    Button submit;

    RadioButton back;
    RadioButton leg;
    RadioButton shoulder;
    RadioButton chest;

    EditText time;

    SwitchCompat trainer;

    AlertDialog.Builder builder;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        builder = new AlertDialog.Builder(this);

        submit =(Button) findViewById(R.id.submit_btn);

        back = (RadioButton) findViewById(R.id.back_btn);
        leg = (RadioButton) findViewById(R.id.leg_btn);
        shoulder = (RadioButton) findViewById(R.id.shoulder_btn);
        chest = (RadioButton) findViewById(R.id.chest_btn);

        time = (EditText) findViewById(R.id.time_edit);

        trainer = (SwitchCompat) findViewById(R.id.trainer_swit);

        submit.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if (checkValidity()) {
                    Toast.makeText(getApplicationContext(), R.string.message, Toast.LENGTH_SHORT).show();

                    String excercise = "";

                    if(back.isChecked())
                        excercise += "Back";
                    else if (leg.isChecked())
                        excercise += "Leg";
                    else if (shoulder.isChecked())
                        excercise += "Shoulder";
                    else if (chest.isChecked())
                        excercise += "Chest";

                    String pt = "";

                    if(trainer.isChecked())
                        pt += "with trainer";
                    else
                        pt += "alone";



                    int a =Integer.parseInt(time.getText().toString());

                    builder.setMessage("You have chosen the excercise " + excercise + " for " + a + " min " + pt)
                            .setCancelable(true)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {

                                }
                            });

                    AlertDialog alert =builder.create();
                    alert.setTitle("Thank you");
                    alert.show();

                }else {
                    Toast.makeText(getApplicationContext(), R.string.errorMessage, Toast.LENGTH_SHORT).show();

                }
            }
        });

        trainer.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    Toast.makeText(getApplicationContext(), R.string.trainer_with, Toast.LENGTH_SHORT).show();
                }
            }
        });



    }

    public boolean checkValidity() {
        boolean valid;
        if (!(back.isChecked() || leg.isChecked() || shoulder.isChecked() || chest.isChecked())) {
            return valid = false;
        }else if (submit.getText().toString().isEmpty()) {
            return valid = false;
        }

        return valid = true;
    }
}
