package com.example.week3listview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    String animalList[] = {};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView listview = (ListView) findViewById(R.id.simpleListView);
        animalList = new String[]{"Lion", "Tiger", "Monkey", "Elephant", "Dog", "Cat", "Camel"};

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, R.layout.list_view_item, R.id.textview, animalList);
        listview.setAdapter(arrayAdapter);

        listview.setOnItemClickListener(messageClickedHandler);


    }
    private AdapterView.OnItemClickListener messageClickedHandler = new AdapterView.OnItemClickListener() {
        public void onItemClick(AdapterView parent, View v, int position, long id) {
            String value = (String)parent.getItemAtPosition(position);
              Toast toast=Toast.makeText(getApplicationContext(),value,Toast.LENGTH_SHORT);
            toast.show();          }
    };

}
