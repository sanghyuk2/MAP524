package com.example.truefalse;

public class True {
    private int mQuestionId;
    private boolean mAnswer;

    public True(int mQuestionId, boolean mAnswer) {
        this.mQuestionId = mQuestionId;
        this.mAnswer = mAnswer;
    }

    public int getmQuestionId() {
        return mQuestionId;
    }

    public boolean ismAnswer() {
        return mAnswer;
    }
}
