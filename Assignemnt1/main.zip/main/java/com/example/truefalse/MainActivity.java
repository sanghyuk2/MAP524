package com.example.truefalse;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.media.Image;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import static java.lang.reflect.Array.*;
import static java.util.Arrays.asList;


public class MainActivity extends AppCompatActivity
{
    private Handler mHandler = new Handler();

    ProgressBar mProgressBar;
    ImageButton mTrueButton;
    ImageButton mFalseButton;
    TextView mQuestionTextView;
    TextView mScoreTextView;
    int mIndex;
    int mScore;
    int mQuestion;
    Toast mToastMessage;
//    private ImageView stare;
    ListView listView;
    ArrayAdapter adapter;




    True q1 = new True(R.string.question1,true);
    True q2 = new True(R.string.question2,true);
    True q3 = new True(R.string.question3,false);
    True q4 = new True(R.string.question4, false);
    True q5 = new True(R.string.question5, true);

    private True[] mquestionbank = new True[] {
            q1, q2, q3, q4, q5
    };


    int PROGRESS_BAR_INCREMENT = (int) Math.ceil(100.0/mquestionbank.length);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTrueButton = findViewById(R.id.correct_btn);
        mFalseButton = findViewById(R.id.wrong_btn);
        mQuestionTextView = findViewById(R.id.question);
        mScoreTextView = findViewById(R.id.score);
        mProgressBar = findViewById(R.id.progress_bar);
//        stare = (ImageView) findViewById(R.id.state_img);
        mQuestion = mquestionbank[mIndex].getmQuestionId();
        mQuestionTextView.setText(mQuestion);

        mTrueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(true);
                updateQuestion();
            }
        });
        mFalseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(false);
                updateQuestion();
            }
        });
    }

    public void startRepeating() {
        shuffleQuestions();
        mHandler.postDelayed(mToastRunnable, 3000);

    }

    private Runnable mToastRunnable = new Runnable() {
        @Override
        public void run() {
            Toast.makeText(MainActivity.this, "The score will be start from 0 once you start again", Toast.LENGTH_SHORT).show();
        }
    };

    private void checkAnswer(boolean userSelection) {
        boolean actualAnswer = mquestionbank[mIndex].ismAnswer();
        if(userSelection == actualAnswer) {
            mScore = mScore + 1;
            Toast.makeText(MainActivity.this, R.string.correct_message, Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(MainActivity.this, R.string.false_message, Toast.LENGTH_SHORT).show();

        }
    }

    private void updateQuestion() {
        mIndex = (mIndex + 1) % mquestionbank.length;
        if(mIndex == 0) {
            AlertDialog.Builder alert = new AlertDialog.Builder(this);
            alert.setTitle("Quiz App");
            alert.setCancelable(false);
            alert.setMessage("You scored " + mScore + "/" + mquestionbank.length)
                    .setPositiveButton("Close Application", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                        }
                    })
                    .setNegativeButton("Repeat Application", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            mProgressBar.setProgress(0);
                            mScore = 0;
                            startRepeating();
                        }
                    });

            alert.show();
        }
        mQuestion = mquestionbank[mIndex].getmQuestionId();
        mQuestionTextView.setText(mQuestion);
        mProgressBar.incrementProgressBy(PROGRESS_BAR_INCREMENT);
        mScoreTextView.setText("Score:" + mScore + "/" + mquestionbank
                .length);
    }

    public void shuffleQuestions() {
        Collections.shuffle(Arrays.asList(mquestionbank));
    }



}
