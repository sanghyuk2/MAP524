package com.example.lab3_sanghyuklee_v2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

public class AllDonationsWithAmountBiggerThan extends AppCompatActivity {
    ListView myList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_donations);

        DatabaseClient.databaseWriteExecutor.execute(()->{
            Donations[] donationList = DatabaseClient.getDatabase().DonationDao().getAllDonationWithAmountBiggerThan(1000); //I set parameter as 1000

            myList = (ListView) findViewById(R.id.alldonationlist);
            DonationAdapter adapter = new DonationAdapter(this,donationList);
            myList.setAdapter(adapter);


        });



    }
}
