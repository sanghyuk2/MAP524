package com.example.lab3_sanghyuklee_v2;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {Donations.class}, version = 1)
public abstract class DonationDataBase extends RoomDatabase {
    public abstract DonationDao DonationDao ();
}
