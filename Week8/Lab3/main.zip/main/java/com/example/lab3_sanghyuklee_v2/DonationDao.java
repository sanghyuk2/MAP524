package com.example.lab3_sanghyuklee_v2;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

@Dao
public interface DonationDao {

    @Query("SELECT * FROM Donations") //Select all the donations from Donations.java class
    public Donations[] getAllDonations();

    @Query("SELECT * FROM Donations WHERE amount > :amount") //Select all the donations from Donations.java class
    public Donations[] getAllDonationWithAmountBiggerThan(int amount);

    @Insert
    public void insertDonation(Donations user);

}
