package com.example.lab3_sanghyuklee_v2;

import android.content.Context;

import androidx.room.Room;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DatabaseClient {
    public static DonationDataBase dDatabase;
    public static DatabaseClient dDBInstance;

    public static final ExecutorService databaseWriteExecutor= Executors.newFixedThreadPool(4);

    public static DatabaseClient getInstance(Context context){
        if (dDBInstance == null) { //check if there is a db or not
            dDatabase = Room.databaseBuilder(context, DonationDataBase.class, "DonationDB").build();
        }
        return dDBInstance;
    }

    public static DonationDataBase getDatabase() {return dDatabase;}

    public static void insertToDB (Context context, Donations don) {
        databaseWriteExecutor.execute(()->{
            getInstance(context).dDatabase.DonationDao().insertDonation(don);
        });
    }
}
